﻿

const cacheName = 'news-v1';
const staticAssets = [
    './',
    '/Theme/js/jquery.min.js',
    'Anonymous/MobileLogin.aspx',
    '/sales/mobile/img/logo.svg',
    '/Theme/js/jquery.min.js',
    '/Theme/css/bootstrap.min.css',
    '/Theme/assets/font-awesome/css/font-awesome.min.css',
    '/sales/mobile/vendor/bootstrap/css/bootstrap.min.css',
    '/Theme/css/helper.css',
    '/sales/mobile/css/style.css',
    '/sales/mobile/vendor/sidebar/demo.css',
    '/sales/mobile/vendor/slick/slick.min.css',
    '/sales/mobile/vendor/slick/slick-theme.min.css',
    '/sales/mobile/vendor/icons/icofont.min.css',
    'manifest.json',
    '../Sales/Mobile/img/mimilogo.svg',
    '/sales/mobile/vendor/jquery/jquery.min.js',
    '/Sales/Mobile/vendor/bootstrap/js/bootstrap.bundle.min.js',
    '/Sales/Mobile/vendor/slick/slick.min.js',
    '/Sales/Mobile/vendor/sidebar/hc-offcanvas-nav.js',
    '/Theme/Custom/Commons.js',
    '/Sales/Mobile/js/osahan.js'
];

self.addEventListener('install', async e => {
    const cache = await caches.open(cacheName);
    await cache.addAll(staticAssets);
    return self.skipWaiting();
});

self.addEventListener('activate', e => {
    self.clients.claim();
});

self.addEventListener('fetch', async e => {
    const req = e.request;
    const url = new URL(req.url);

    if (url.origin === location.origin) {
        e.respondWith(cacheFirst(req));
    } else {
        e.respondWith(networkAndCache(req));
    }
});

async function cacheFirst(req) {
    const cache = await caches.open(cacheName);
    const cached = await cache.match(req);
    return cached || fetch(req);
}

async function networkAndCache(req) {
    const cache = await caches.open(cacheName);
    try {
        const fresh = await fetch(req);
        await cache.put(req, fresh.clone());
        return fresh;
    } catch (e) {
        const cached = await cache.match(req);
        return cached;
    }
}